package com.example.demo5;

public class ManageInventory {
}
